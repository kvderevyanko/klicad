# CPL rotation notes

CPL_SMD_REV1.csv is KiCad's direct position export. Its X, Y, side, and
rotation are authoritative board-export values; do not remap angles to an
assembler convention without validating that assembler's import preview.

Check pin 1 for U1 TPS62133, U3 SN74AHCT1G125, U4 TLV1117LV33, and Q1
DMP3130LQ-7 in PCBWAVE's import preview. Place L1 with the Coilcraft
start-lead mark toward PCB pad 1 (BUCK_SW). D3 SMBJ10CA is bidirectional
and F1 is non-polar. Use assembly-top.pdf and silkscreen-top.pdf to confirm
the vendor's rotation convention.
