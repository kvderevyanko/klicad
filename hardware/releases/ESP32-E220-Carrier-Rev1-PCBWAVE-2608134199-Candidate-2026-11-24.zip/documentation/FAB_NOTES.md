# Rev.1 fabrication notes

## Verified board

- Board: 145 x 90 mm
- Layers: 2
- Fabrication set: F.Cu, B.Cu, F.Mask, B.Mask, F.SilkS, Edge.Cuts, and separate PTH/NPTH Excellon drills.
- Stencil set: F.Paste. U1 exposed-pad aperture is 1.55 × 1.55 mm (85% of copper area). Confirm stencil thickness and paste release with PCBWAVE.

## PCBWAVE order 2608134199

- Quantities: fabricate 5 PCB, assemble 4 PCBA
- Material: FR-4
- Nominal thickness: 1.6 mm
- Outer copper: 1 oz (approximately 35 um)
- Solder mask: black
- Silkscreen: white
- Finish: lead-free HASL

Rev.1 has no controlled-impedance requirement, castellations, edge plating,
blind vias, or buried vias.

## First-article notes

- J4/J8 JST B2B-XH-A: finished plated holes Ø1.00 ±0.05 mm on 2.50 ±0.05 mm pitch. Confirm the finished-hole tolerance during CAM review.
- Verify OLED mechanical/body fit on the actual module.
- Rev.1 has three M3 mounting holes: H1/H2/H3, each 3.20-mm NPTH with an 8-mm copper-free screw-head region. Enclosure/standoffs must respect these mechanical clearances.
- Battery strain relief is enclosure/harness responsibility.
- Visually/process inspect the U1 exposed-pad assembly.
- U4 operating temperature may be checked during first-article power validation.
- Prototype power-transient validation remains recommended.
